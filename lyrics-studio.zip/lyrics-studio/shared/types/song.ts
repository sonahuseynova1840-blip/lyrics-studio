export type SongLanguage = 'ru' | 'az' | 'de' | 'mix';
export type RhymeScheme = 'AABB' | 'ABAB' | 'FREE';

export interface SongSettings {
  language: SongLanguage;
  style: string; // e.g. Pop, Rap
  genre: string; // e.g. Trap, Ballad
  mood: string; // e.g. Dark, Romantic
  tempo: 'slow' | 'medium' | 'fast';
  density: 'low' | 'medium' | 'high';
  rhyme: RhymeScheme;
  persona: string;
  theme: string;
  keywords: string[];
  structure: {
    introLines: number;
    verse1Lines: number;
    hookLines: number;
    verse2Lines: number;
    bridgeLines: number;
    outroLines: number;
  };
}

export type SectionName = 'Intro' | 'Verse 1' | 'Hook' | 'Verse 2' | 'Bridge' | 'Outro';

export interface SongSection {
  name: SectionName;
  text: string;
}

export interface SongVersion {
  sections: SongSection[];
}

export interface LyricsResponse {
  versions: {
    A: SongVersion;
    B: SongVersion;
    C: SongVersion;
  };
  meta: SongSettings;
}
