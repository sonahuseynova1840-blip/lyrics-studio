# TODO (next iterations)

- Section-by-section regeneration with validation per section
- Real rhyme-scheme validator (AABB/ABAB) per language
- Caching (hash prompt+settings) to avoid duplicates
- Audio generation providers abstraction (Suno-like backends)
- Export `.md` + “Suno-ready” copy format
- Project delete + rename UI
- Rate-limit & cooldown mapping (429) + countdown UI

