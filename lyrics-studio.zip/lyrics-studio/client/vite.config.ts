import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const target = mode === 'development' ? 'http://localhost:8787' : undefined;
  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: target
        ? {
            '/api': {
              target,
              changeOrigin: true,
            },
          }
        : undefined,
    },
  };
});
