import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import ru from './ru.json';
import az from './az.json';
import { uiStore } from '../store/uiStore';

const resources = {
  ru: { translation: ru },
  az: { translation: az },
} as const;

const initialLang = uiStore.getState().uiLanguage;

i18n.use(initReactI18next).init({
  resources,
  lng: initialLang,
  fallbackLng: 'ru',
  interpolation: { escapeValue: false },
});

uiStore.subscribe((s) => {
  if (i18n.language !== s.uiLanguage) i18n.changeLanguage(s.uiLanguage);
});

export default i18n;
