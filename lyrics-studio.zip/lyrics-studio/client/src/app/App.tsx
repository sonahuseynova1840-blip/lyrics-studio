import { BrowserRouter, NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { uiStore } from '../store/uiStore';
import { ProjectsPage } from '../pages/ProjectsPage';
import { StudioPage } from '../pages/StudioPage';
import { VoicePage } from '../pages/VoicePage';
import { SettingsPage } from '../pages/SettingsPage';

function Header() {
  const { t } = useTranslation();
  const uiLanguage = uiStore((s) => s.uiLanguage);
  const theme = uiStore((s) => s.theme);
  const setLanguage = uiStore((s) => s.setLanguage);
  const setTheme = uiStore((s) => s.setTheme);
  const [themeOpen, setThemeOpen] = useState(false);

  const themeOptions = useMemo(
    () => [
      { id: 'neon', label: 'Neon Blue' },
      { id: 'purple', label: 'Purple Night' },
      { id: 'green', label: 'Emerald Green' },
      { id: 'sunset', label: 'Sunset Orange' },
      { id: 'light', label: 'Light Minimal' },
    ] as const,
    [],
  );

  return (
    <div className="sticky top-0 z-20 border-b" style={{ borderColor: 'rgb(var(--border))' }}>
      <div className="flex items-center justify-between px-4 py-3" style={{ background: 'rgb(var(--panel))' }}>
        <div className="flex items-center gap-3">
          <div className="text-lg font-semibold tracking-tight">
            <span style={{ color: 'rgb(var(--primary))' }}>Lyrics</span> Studio
          </div>
          <nav className="hidden sm:flex items-center gap-2 text-sm">
            <NavLink
              to="/studio"
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl ${isActive ? 'font-semibold' : 'opacity-80 hover:opacity-100'}`
              }
            >
              {t('app.studio')}
            </NavLink>
            <NavLink
              to="/projects"
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl ${isActive ? 'font-semibold' : 'opacity-80 hover:opacity-100'}`
              }
            >
              {t('app.projects')}
            </NavLink>
            <NavLink
              to="/voice"
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl ${isActive ? 'font-semibold' : 'opacity-80 hover:opacity-100'}`
              }
            >
              {t('app.voice')}
            </NavLink>
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-xl ${isActive ? 'font-semibold' : 'opacity-80 hover:opacity-100'}`
              }
            >
              {t('app.settings')}
            </NavLink>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {/* Language button */}
          <button
            className="px-3 py-1.5 rounded-xl border text-sm"
            style={{ borderColor: 'rgb(var(--border))' }}
            onClick={() => setLanguage(uiLanguage === 'ru' ? 'az' : 'ru')}
            aria-label="Toggle UI language"
          >
            {uiLanguage.toUpperCase()}
          </button>

          {/* Theme button */}
          <div className="relative">
            <button
              className="px-3 py-1.5 rounded-xl border text-sm"
              style={{ borderColor: 'rgb(var(--border))' }}
              onClick={() => setThemeOpen((v) => !v)}
              aria-label="Theme"
            >
              🎨
            </button>
            {themeOpen ? (
              <div
                className="absolute right-0 mt-2 w-48 rounded-xl border shadow-lg overflow-hidden"
                style={{ background: 'rgb(var(--panel))', borderColor: 'rgb(var(--border))' }}
              >
                {themeOptions.map((o) => (
                  <button
                    key={o.id}
                    className={`w-full text-left px-3 py-2 text-sm hover:opacity-95 ${
                      theme === o.id ? 'font-semibold' : 'opacity-90'
                    }`}
                    onClick={() => {
                      setTheme(o.id);
                      setThemeOpen(false);
                    }}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

function RootRedirect() {
  const nav = useNavigate();
  useEffect(() => {
    nav('/projects', { replace: true });
  }, [nav]);
  return null;
}

export function App() {
  const theme = uiStore((s) => s.theme);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/studio" element={<StudioPage />} />
        <Route path="/studio/:projectId" element={<StudioPage />} />
        <Route path="/voice" element={<VoicePage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<div className="p-6 opacity-80">404</div>} />
      </Routes>
    </BrowserRouter>
  );
}
