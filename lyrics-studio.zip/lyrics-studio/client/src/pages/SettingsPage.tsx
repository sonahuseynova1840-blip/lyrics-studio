import { useTranslation } from 'react-i18next';

export function SettingsPage() {
  const { t } = useTranslation();
  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-xl font-semibold">{t('app.settings')}</h1>
      <div
        className="mt-4 p-4 rounded-xl border max-w-2xl"
        style={{ background: 'rgb(var(--panel))', borderColor: 'rgb(var(--border))' }}
      >
        <div className="text-sm opacity-80">
          This build uses a secure server API. To enable generation, set <b>OPENAI_API_KEY</b> in server
          environment.
        </div>
      </div>
    </div>
  );
}
