import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { projectStore } from '../store/projectStore';

export function ProjectsPage() {
  const { t } = useTranslation();
  const nav = useNavigate();
  const { projects, isLoading, error, loadProjects, createProject } = projectStore();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');

  useEffect(() => {
    void loadProjects();
  }, [loadProjects]);

  return (
    <div className="p-4 sm:p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">{t('app.projects')}</h1>
        <button
          className="px-4 py-2 rounded-xl text-sm font-semibold"
          style={{ background: 'rgb(var(--primary))', color: 'rgb(var(--bg))' }}
          onClick={() => setOpen(true)}
        >
          {t('app.createProject')}
        </button>
      </div>

      {error ? (
        <div className="mt-4 p-3 rounded-xl border" style={{ borderColor: 'rgb(var(--border))' }}>
          <div className="font-semibold">{t('app.error')}</div>
          <div className="opacity-80 text-sm mt-1">{error}</div>
        </div>
      ) : null}

      <div className="mt-4 grid gap-3">
        {isLoading ? <div className="opacity-70">Loading…</div> : null}
        {!isLoading && projects.length === 0 ? (
          <div className="opacity-80">{t('app.noProjects')}</div>
        ) : null}
        {projects.map((p) => (
          <button
            key={p.id}
            className="text-left p-4 rounded-xl border hover:opacity-95"
            style={{ background: 'rgb(var(--panel))', borderColor: 'rgb(var(--border))' }}
            onClick={() => nav(`/studio/${p.id}`)}
          >
            <div className="font-semibold">{p.title}</div>
            <div className="text-sm opacity-70 mt-1">
              {new Date(p.updatedAt).toLocaleString()}
            </div>
          </button>
        ))}
      </div>

      {open ? (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/50 p-4">
          <div
            className="w-full max-w-md rounded-xl border p-4"
            style={{ background: 'rgb(var(--panel))', borderColor: 'rgb(var(--border))' }}
          >
            <div className="font-semibold">{t('app.createProject')}</div>
            <label className="block mt-3 text-sm opacity-80">{t('app.projectTitle')}</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-xl border bg-transparent"
              style={{ borderColor: 'rgb(var(--border))' }}
              placeholder="My first track"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                className="px-3 py-2 rounded-xl border text-sm"
                style={{ borderColor: 'rgb(var(--border))' }}
                onClick={() => {
                  setOpen(false);
                  setTitle('');
                }}
              >
                {t('app.cancel')}
              </button>
              <button
                className="px-4 py-2 rounded-xl text-sm font-semibold"
                style={{ background: 'rgb(var(--primary))', color: 'rgb(var(--bg))' }}
                onClick={async () => {
                  const clean = title.trim();
                  if (!clean) return;
                  const p = await createProject(clean);
                  setOpen(false);
                  setTitle('');
                  nav(`/studio/${p.id}`);
                }}
              >
                {t('app.create')}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
