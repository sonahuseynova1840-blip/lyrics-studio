import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { projectStore } from '../store/projectStore';
import { apiFetch } from '../lib/api';
import type { SongLanguage } from '../../../shared/types/song';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

const LANG_OPTIONS: { id: SongLanguage; label: string }[] = [
  { id: 'ru', label: 'RU' },
  { id: 'az', label: 'AZ' },
  { id: 'de', label: 'DE' },
  { id: 'mix', label: 'MIX' },
];

export function StudioPage() {
  const { t } = useTranslation();
  const { projectId } = useParams();
  const { current, isLoading, error, openProject, updateSettings, generateLyrics, exportTxt } = projectStore();
  const [activeVersion, setActiveVersion] = useState<'A' | 'B' | 'C'>('A');

  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatBusy, setChatBusy] = useState(false);

  useEffect(() => {
    if (projectId) void openProject(projectId);
  }, [projectId, openProject]);

  useEffect(() => {
    const id = current?.id;
    if (!id) return;
    void (async () => {
      try {
        const msgs = await apiFetch<ChatMessage[]>(`/api/projects/${id}/messages`);
        setChat(msgs);
      } catch {
        setChat([]);
      }
    })();
  }, [current?.id]);

  const versions = current?.lyrics?.versions;
  const active = versions?.[activeVersion];

  const sectionText = useMemo(() => {
    if (!active) return '';
    return active.sections.map((s) => `[${s.name}]\n${s.text.trim()}\n`).join('\n');
  }, [active]);

  async function sendChat(content: string) {
    const id = current?.id;
    if (!id) return;
    setChatBusy(true);
    try {
      const msg = await apiFetch<ChatMessage>(`/api/projects/${id}/messages`, {
        method: 'POST',
        body: JSON.stringify({ content }),
      });
      setChat((c) => [...c, { id: msg.id + '-u', role: 'user', content, createdAt: new Date().toISOString() }, msg]);
      setChatInput('');
    } catch (e: any) {
      setChat((c) => [
        ...c,
        {
          id: 'err-' + Date.now(),
          role: 'assistant',
          content: `${t('app.error')}: ${e?.message ?? 'Failed'}`,
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setChatBusy(false);
    }
  }

  if (!current) {
    return (
      <div className="p-6">
        <div className="opacity-80">{t('app.selectProject')}</div>
        {error ? <div className="mt-3 text-sm opacity-70">{error}</div> : null}
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-4">
        {/* Main editor */}
        <div className="rounded-xl border" style={{ borderColor: 'rgb(var(--border))', background: 'rgb(var(--panel))' }}>
          <div className="p-4 border-b" style={{ borderColor: 'rgb(var(--border))' }}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-lg font-semibold">{current.title}</div>
                <div className="text-xs opacity-70">{new Date(current.updatedAt).toLocaleString()}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  className="px-3 py-2 rounded-xl border text-sm"
                  style={{ borderColor: 'rgb(var(--border))' }}
                  onClick={() => exportTxt()}
                >
                  {t('app.exportTxt')}
                </button>
                <button
                  className="px-3 py-2 rounded-xl text-sm font-semibold"
                  style={{ background: 'rgb(var(--primary))', color: 'rgb(var(--bg))' }}
                  onClick={() => void generateLyrics()}
                  disabled={isLoading}
                >
                  {t('app.generateLyrics')}
                </button>
              </div>
            </div>

            {/* Controls */}
            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
              <div>
                <div className="opacity-70 mb-1">{t('app.language')}</div>
                <select
                  value={current.settings.language}
                  onChange={(e) => void updateSettings({ language: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                >
                  {LANG_OPTIONS.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.style')}</div>
                <input
                  value={current.settings.style}
                  onChange={(e) => void updateSettings({ style: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                  placeholder="Rap"
                />
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.genre')}</div>
                <input
                  value={current.settings.genre}
                  onChange={(e) => void updateSettings({ genre: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                  placeholder="Trap"
                />
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.mood')}</div>
                <input
                  value={current.settings.mood}
                  onChange={(e) => void updateSettings({ mood: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                  placeholder="Cinematic"
                />
              </div>

              <div>
                <div className="opacity-70 mb-1">{t('app.tempo')}</div>
                <select
                  value={current.settings.tempo}
                  onChange={(e) => void updateSettings({ tempo: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                >
                  <option value="slow">slow</option>
                  <option value="medium">medium</option>
                  <option value="fast">fast</option>
                </select>
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.density')}</div>
                <select
                  value={current.settings.density}
                  onChange={(e) => void updateSettings({ density: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                >
                  <option value="low">low</option>
                  <option value="medium">medium</option>
                  <option value="high">high</option>
                </select>
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.rhyme')}</div>
                <select
                  value={current.settings.rhyme}
                  onChange={(e) => void updateSettings({ rhyme: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                >
                  <option value="AABB">AABB</option>
                  <option value="ABAB">ABAB</option>
                  <option value="FREE">FREE</option>
                </select>
              </div>
              <div>
                <div className="opacity-70 mb-1">{t('app.persona')}</div>
                <input
                  value={current.settings.persona}
                  onChange={(e) => void updateSettings({ persona: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                />
              </div>
              <div className="col-span-2">
                <div className="opacity-70 mb-1">{t('app.theme')}</div>
                <input
                  value={current.settings.theme}
                  onChange={(e) => void updateSettings({ theme: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                />
              </div>
              <div className="col-span-2">
                <div className="opacity-70 mb-1">{t('app.keywords')}</div>
                <input
                  value={current.settings.keywords.join(', ')}
                  onChange={(e) =>
                    void updateSettings({
                      keywords: e.target.value
                        .split(',')
                        .map((s) => s.trim())
                        .filter(Boolean),
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl border bg-transparent"
                  style={{ borderColor: 'rgb(var(--border))' }}
                />
              </div>
            </div>
          </div>

          <div className="p-4">
            {error ? (
              <div className="mb-3 p-3 rounded-xl border" style={{ borderColor: 'rgb(var(--border))' }}>
                <div className="font-semibold">{t('app.error')}</div>
                <div className="text-sm opacity-80 mt-1">{error}</div>
              </div>
            ) : null}

            <div className="flex items-center gap-2">
              {(['A', 'B', 'C'] as const).map((v) => (
                <button
                  key={v}
                  onClick={() => setActiveVersion(v)}
                  className={`px-3 py-1.5 rounded-xl border text-sm ${
                    activeVersion === v ? 'font-semibold' : 'opacity-80'
                  }`}
                  style={{ borderColor: 'rgb(var(--border))' }}
                >
                  {v}
                </button>
              ))}

              <div className="flex-1" />
              <button
                className="px-3 py-2 rounded-xl border text-sm"
                style={{ borderColor: 'rgb(var(--border))' }}
                onClick={() => navigator.clipboard.writeText(sectionText)}
                disabled={!active}
              >
                Copy
              </button>
            </div>

            <textarea
              className="mt-3 w-full min-h-[360px] px-3 py-3 rounded-xl border bg-transparent font-mono text-sm"
              style={{ borderColor: 'rgb(var(--border))' }}
              value={sectionText}
              readOnly
            />
          </div>
        </div>

        {/* Assistant */}
        <div className="rounded-xl border h-[calc(100vh-140px)] flex flex-col" style={{ borderColor: 'rgb(var(--border))', background: 'rgb(var(--panel))' }}>
          <div className="p-4 border-b" style={{ borderColor: 'rgb(var(--border))' }}>
            <div className="font-semibold">{t('app.assistant')}</div>
            <div className="text-xs opacity-70 mt-1">Context-aware song co-writer</div>
          </div>

          <div className="flex-1 overflow-auto p-4 space-y-3">
            {chat.length === 0 ? <div className="text-sm opacity-70">Ask for rhyme ideas, hooks, edits…</div> : null}
            {chat.map((m) => (
              <div key={m.id} className={`text-sm ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
                <div
                  className={`inline-block max-w-[90%] rounded-xl px-3 py-2 border ${
                    m.role === 'user' ? 'opacity-95' : 'opacity-90'
                  }`}
                  style={{
                    borderColor: 'rgb(var(--border))',
                    background: m.role === 'user' ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.05)',
                  }}
                >
                  {m.content}
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 border-t" style={{ borderColor: 'rgb(var(--border))' }}>
            <div className="flex gap-2">
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 px-3 py-2 rounded-xl border bg-transparent text-sm"
                style={{ borderColor: 'rgb(var(--border))' }}
                placeholder="Improve the hook, add internal rhymes…"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    const c = chatInput.trim();
                    if (c && !chatBusy) void sendChat(c);
                  }
                }}
              />
              <button
                className="px-3 py-2 rounded-xl text-sm font-semibold"
                style={{ background: 'rgb(var(--primary))', color: 'rgb(var(--bg))' }}
                onClick={() => {
                  const c = chatInput.trim();
                  if (c && !chatBusy) void sendChat(c);
                }}
                disabled={chatBusy}
              >
                {t('app.send')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
