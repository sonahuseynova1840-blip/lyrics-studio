import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { projectStore, type AudioItem } from '../store/projectStore';

export function VoicePage() {
  const { t } = useTranslation();
  const { projects, current, loadProjects, openProject, generateVoice, listAudio, isLoading, error } = projectStore();
  const [audio, setAudio] = useState<AudioItem[]>([]);

  useEffect(() => {
    void loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    if (!current) return;
    void (async () => {
      const items = await listAudio();
      setAudio(items);
    })();
  }, [current?.id, listAudio]);

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-xl font-semibold">{t('app.voice')}</h1>

      <div className="mt-4 grid gap-3 max-w-2xl">
        <div>
          <div className="text-sm opacity-70 mb-1">{t('app.selectProject')}</div>
          <select
            value={current?.id ?? ''}
            onChange={(e) => void openProject(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border bg-transparent"
            style={{ borderColor: 'rgb(var(--border))' }}
          >
            <option value="" disabled>
              —
            </option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title}
              </option>
            ))}
          </select>
        </div>

        <button
          className="px-4 py-2 rounded-xl text-sm font-semibold w-fit"
          style={{ background: 'rgb(var(--primary))', color: 'rgb(var(--bg))' }}
          onClick={async () => {
            const item = await generateVoice();
            setAudio((a) => [item, ...a]);
          }}
          disabled={isLoading || !current}
        >
          {t('app.generateVoice')}
        </button>

        {error ? (
          <div className="p-3 rounded-xl border" style={{ borderColor: 'rgb(var(--border))' }}>
            <div className="font-semibold">{t('app.error')}</div>
            <div className="text-sm opacity-80 mt-1">{error}</div>
          </div>
        ) : null}

        <div className="mt-2 grid gap-3">
          {audio.map((a) => (
            <div
              key={a.id}
              className="p-4 rounded-xl border"
              style={{ background: 'rgb(var(--panel))', borderColor: 'rgb(var(--border))' }}
            >
              <div className="text-sm opacity-70">{new Date(a.createdAt).toLocaleString()}</div>
              <audio className="mt-2 w-full" controls src={a.url} />
              <a
                className="text-sm underline mt-2 inline-block"
                href={a.url}
                target="_blank"
                rel="noreferrer"
                style={{ color: 'rgb(var(--primary))' }}
              >
                Download
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
