import { create } from 'zustand';

export type UiLanguage = 'ru' | 'az';
export type UiTheme = 'neon' | 'purple' | 'green' | 'sunset' | 'light';

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export const uiStore = create<{
  uiLanguage: UiLanguage;
  theme: UiTheme;
  setLanguage: (l: UiLanguage) => void;
  setTheme: (t: UiTheme) => void;
}>()((set) => ({
  uiLanguage: load<UiLanguage>('ui.lang', 'ru'),
  theme: load<UiTheme>('ui.theme', 'neon'),
  setLanguage: (l) =>
    set(() => {
      localStorage.setItem('ui.lang', JSON.stringify(l));
      return { uiLanguage: l };
    }),
  setTheme: (t) =>
    set(() => {
      localStorage.setItem('ui.theme', JSON.stringify(t));
      return { theme: t };
    }),
}));
