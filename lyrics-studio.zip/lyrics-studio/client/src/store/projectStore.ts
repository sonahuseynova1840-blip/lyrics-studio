import { create } from 'zustand';
import { apiFetch } from '../lib/api';
import type { LyricsResponse, SongSettings } from '../../../shared/types/song';

export interface Project {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  settings: SongSettings;
  lyrics?: LyricsResponse;
}

export interface AudioItem {
  id: string;
  projectId: string;
  createdAt: string;
  voice: string;
  url: string;
}

const defaultSettings: SongSettings = {
  language: 'ru',
  style: 'Rap',
  genre: 'Trap',
  mood: 'Cinematic',
  tempo: 'medium',
  density: 'high',
  rhyme: 'AABB',
  persona: 'determined migrant narrator',
  theme: 'migration, work, goal, overcoming difficulties',
  keywords: ['ночь', 'дорога', 'работа', 'цель', 'надежда'],
  structure: {
    introLines: 4,
    verse1Lines: 16,
    hookLines: 8,
    verse2Lines: 16,
    bridgeLines: 6,
    outroLines: 4,
  },
};

export const projectStore = create<{
  projects: Project[];
  current?: Project;
  isLoading: boolean;
  error?: string;
  loadProjects: () => Promise<void>;
  createProject: (title: string) => Promise<Project>;
  openProject: (id: string) => Promise<void>;
  updateSettings: (partial: Partial<SongSettings>) => Promise<void>;
  generateLyrics: () => Promise<void>;
  exportTxt: () => void;
  listAudio: () => Promise<AudioItem[]>;
  generateVoice: () => Promise<AudioItem>;
}>()((set, get) => ({
  projects: [],
  current: undefined,
  isLoading: false,
  error: undefined,

  loadProjects: async () => {
    set({ isLoading: true, error: undefined });
    try {
      const data = await apiFetch<Project[]>('/api/projects');
      set({ projects: data, isLoading: false });
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to load projects', isLoading: false });
    }
  },

  createProject: async (title) => {
    set({ isLoading: true, error: undefined });
    try {
      const p = await apiFetch<Project>('/api/projects', {
        method: 'POST',
        body: JSON.stringify({ title, settings: defaultSettings }),
      });
      set({ isLoading: false });
      await get().loadProjects();
      return p;
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to create project', isLoading: false });
      throw e;
    }
  },

  openProject: async (id) => {
    set({ isLoading: true, error: undefined });
    try {
      const p = await apiFetch<Project>(`/api/projects/${id}`);
      set({ current: p, isLoading: false });
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to open project', isLoading: false });
    }
  },

  updateSettings: async (partial) => {
    const cur = get().current;
    if (!cur) return;
    const next = { ...cur.settings, ...partial };
    set({ current: { ...cur, settings: next } });
    try {
      const updated = await apiFetch<Project>(`/api/projects/${cur.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ settings: next }),
      });
      set({ current: updated });
      await get().loadProjects();
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to save', isLoading: false });
    }
  },

  generateLyrics: async () => {
    const cur = get().current;
    if (!cur) return;
    set({ isLoading: true, error: undefined });
    try {
      const lyrics = await apiFetch<LyricsResponse>(`/api/projects/${cur.id}/lyrics/generate`, {
        method: 'POST',
        body: JSON.stringify({ settings: cur.settings }),
      });
      const updated = await apiFetch<Project>(`/api/projects/${cur.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ lyrics }),
      });
      set({ current: updated, isLoading: false });
      await get().loadProjects();
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to generate lyrics', isLoading: false });
    }
  },

  exportTxt: () => {
    const cur = get().current;
    if (!cur?.lyrics) return;
    const build = (v: 'A' | 'B' | 'C') =>
      cur.lyrics!.versions[v].sections.map((s) => `[${s.name}]\n${s.text.trim()}\n`).join('\n');
    const content =
      `# ${cur.title}\n\n` +
      `Settings: ${JSON.stringify(cur.settings, null, 2)}\n\n` +
      ['A', 'B', 'C'].map((v) => `\n--- VERSION ${v} ---\n\n${build(v as any)}`).join('\n');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${cur.title.replaceAll(/[^a-zA-Z0-9_-]+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  },

  listAudio: async () => {
    const cur = get().current;
    if (!cur) return [];
    return apiFetch<AudioItem[]>(`/api/projects/${cur.id}/audio`);
  },

  generateVoice: async () => {
    const cur = get().current;
    if (!cur) throw new Error('No project');
    if (!cur.lyrics) throw new Error('Generate lyrics first');
    set({ isLoading: true, error: undefined });
    try {
      const item = await apiFetch<AudioItem>(`/api/projects/${cur.id}/audio/generate`, {
        method: 'POST',
        body: JSON.stringify({ voice: 'alloy' }),
      });
      set({ isLoading: false });
      return item;
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to generate voice', isLoading: false });
      throw e;
    }
  },
}));
