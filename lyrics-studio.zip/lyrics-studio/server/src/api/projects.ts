import { Router } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { openDb } from '../db/db';
import type { LyricsResponse, SongSettings } from '../sharedTypes';
import { generateLyrics } from '../ai/generateLyrics';
import { assistantReply } from '../ai/assistant';
import { generateVoiceMp3 } from '../tts/tts';

const SongSettingsSchema = z.object({
  language: z.enum(['ru', 'az', 'de', 'mix']),
  style: z.string().min(1),
  genre: z.string().min(1),
  mood: z.string().min(1),
  tempo: z.enum(['slow', 'medium', 'fast']),
  density: z.enum(['low', 'medium', 'high']),
  rhyme: z.enum(['AABB', 'ABAB', 'FREE']),
  persona: z.string().min(1),
  theme: z.string().min(1),
  keywords: z.array(z.string()).max(30),
  structure: z.object({
    introLines: z.number().int().min(1).max(16),
    verse1Lines: z.number().int().min(4).max(32),
    hookLines: z.number().int().min(2).max(24),
    verse2Lines: z.number().int().min(4).max(32),
    bridgeLines: z.number().int().min(2).max(24),
    outroLines: z.number().int().min(1).max(16),
  }),
});

const CreateProjectSchema = z.object({
  title: z.string().min(1).max(120),
  settings: SongSettingsSchema,
});

const PatchProjectSchema = z.object({
  title: z.string().min(1).max(120).optional(),
  settings: SongSettingsSchema.optional(),
  lyrics: z.any().optional(),
});

export function projectsRouter(dbPath: string) {
  const r = Router();

  r.get('/projects', (_req, res) => {
    const db = openDb(dbPath);
    const rows = db
      .prepare('SELECT id, title, createdAt, updatedAt, settingsJson, lyricsJson FROM projects ORDER BY updatedAt DESC')
      .all() as any[];
    db.close();

    const out = rows.map((x) => ({
      id: x.id,
      title: x.title,
      createdAt: x.createdAt,
      updatedAt: x.updatedAt,
      settings: JSON.parse(x.settingsJson) as SongSettings,
      lyrics: x.lyricsJson ? (JSON.parse(x.lyricsJson) as LyricsResponse) : undefined,
    }));

    res.json(out);
  });

  r.post('/projects', (req, res) => {
    const parsed = CreateProjectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ code: 'BAD_REQUEST', message: parsed.error.message });

    const now = new Date().toISOString();
    const id = nanoid();
    const db = openDb(dbPath);
    db.prepare(
      'INSERT INTO projects (id, title, createdAt, updatedAt, settingsJson, lyricsJson) VALUES (@id, @title, @createdAt, @updatedAt, @settingsJson, NULL)',
    ).run({
      id,
      title: parsed.data.title,
      createdAt: now,
      updatedAt: now,
      settingsJson: JSON.stringify(parsed.data.settings),
    });
    db.close();

    res.json({ id, title: parsed.data.title, createdAt: now, updatedAt: now, settings: parsed.data.settings });
  });

  r.get('/projects/:id', (req, res) => {
    const id = String(req.params.id);
    const db = openDb(dbPath);
    const row = db
      .prepare('SELECT id, title, createdAt, updatedAt, settingsJson, lyricsJson FROM projects WHERE id=?')
      .get(id) as any;
    db.close();
    if (!row) return res.status(404).json({ code: 'NOT_FOUND', message: 'Project not found' });

    res.json({
      id: row.id,
      title: row.title,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      settings: JSON.parse(row.settingsJson),
      lyrics: row.lyricsJson ? JSON.parse(row.lyricsJson) : undefined,
    });
  });

  r.patch('/projects/:id', (req, res) => {
    const id = String(req.params.id);
    const parsed = PatchProjectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ code: 'BAD_REQUEST', message: parsed.error.message });

    const db = openDb(dbPath);
    const row = db.prepare('SELECT id FROM projects WHERE id=?').get(id) as any;
    if (!row) {
      db.close();
      return res.status(404).json({ code: 'NOT_FOUND', message: 'Project not found' });
    }

    const now = new Date().toISOString();
    const cur = db
      .prepare('SELECT title, settingsJson, lyricsJson FROM projects WHERE id=?')
      .get(id) as { title: string; settingsJson: string; lyricsJson: string | null };

    const title = parsed.data.title ?? cur.title;
    const settingsJson = parsed.data.settings ? JSON.stringify(parsed.data.settings) : cur.settingsJson;
    const lyricsJson = parsed.data.lyrics ? JSON.stringify(parsed.data.lyrics) : cur.lyricsJson;

    db.prepare('UPDATE projects SET title=?, settingsJson=?, lyricsJson=?, updatedAt=? WHERE id=?').run(
      title,
      settingsJson,
      lyricsJson,
      now,
      id,
    );
    const updated = db
      .prepare('SELECT id, title, createdAt, updatedAt, settingsJson, lyricsJson FROM projects WHERE id=?')
      .get(id) as any;
    db.close();

    res.json({
      id: updated.id,
      title: updated.title,
      createdAt: updated.createdAt,
      updatedAt: updated.updatedAt,
      settings: JSON.parse(updated.settingsJson),
      lyrics: updated.lyricsJson ? JSON.parse(updated.lyricsJson) : undefined,
    });
  });

  r.post('/projects/:id/lyrics/generate', async (req, res) => {
    const id = String(req.params.id);
    const settingsParsed = SongSettingsSchema.safeParse(req.body?.settings);
    if (!settingsParsed.success) return res.status(400).json({ code: 'BAD_REQUEST', message: settingsParsed.error.message });

    try {
      const lyrics = await generateLyrics(settingsParsed.data);
      res.json(lyrics);
    } catch (e: any) {
      const msg = e?.message ?? 'Generation failed';
      if (msg.includes('OPENAI_API_KEY')) {
        return res.status(500).json({ code: 'MISSING_OPENAI_KEY', message: msg });
      }
      res.status(500).json({ code: 'GENERATION_FAILED', message: msg });
    }
  });

  // Messages
  r.get('/projects/:id/messages', (req, res) => {
    const projectId = String(req.params.id);
    const db = openDb(dbPath);
    const rows = db
      .prepare('SELECT id, role, content, createdAt FROM messages WHERE projectId=? ORDER BY createdAt ASC')
      .all(projectId) as any[];
    db.close();
    res.json(rows);
  });

  r.post('/projects/:id/messages', async (req, res) => {
    const projectId = String(req.params.id);
    const parsed = z.object({ content: z.string().min(1).max(2000) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ code: 'BAD_REQUEST', message: parsed.error.message });

    const db = openDb(dbPath);
    const proj = db
      .prepare('SELECT settingsJson, lyricsJson FROM projects WHERE id=?')
      .get(projectId) as { settingsJson: string; lyricsJson: string | null } | undefined;
    if (!proj) {
      db.close();
      return res.status(404).json({ code: 'NOT_FOUND', message: 'Project not found' });
    }

    const settings = JSON.parse(proj.settingsJson) as SongSettings;
    const lyrics = proj.lyricsJson ? (JSON.parse(proj.lyricsJson) as LyricsResponse) : null;

    try {
      const answer = await assistantReply({ settings, userMessage: parsed.data.content, lyrics });
      const now = new Date().toISOString();
      const id = nanoid();
      db.prepare('INSERT INTO messages (id, projectId, role, content, createdAt) VALUES (?,?,?,?,?)').run(
        id,
        projectId,
        'assistant',
        answer,
        now,
      );
      db.close();
      res.json({ id, role: 'assistant', content: answer, createdAt: now });
    } catch (e: any) {
      db.close();
      const msg = e?.message ?? 'Assistant failed';
      if (msg.includes('OPENAI_API_KEY')) return res.status(500).json({ code: 'MISSING_OPENAI_KEY', message: msg });
      res.status(500).json({ code: 'ASSISTANT_FAILED', message: msg });
    }
  });

  // Audio
  r.get('/projects/:id/audio', (req, res) => {
    const projectId = String(req.params.id);
    const db = openDb(dbPath);
    const rows = db
      .prepare('SELECT id, projectId, voice, filePath, createdAt FROM audio WHERE projectId=? ORDER BY createdAt DESC')
      .all(projectId) as any[];
    db.close();
    res.json(
      rows.map((x) => ({
        id: x.id,
        projectId: x.projectId,
        voice: x.voice,
        createdAt: x.createdAt,
        url: `/storage/${x.filePath.split(/[\\/]/).pop()}`,
      })),
    );
  });

  r.post('/projects/:id/audio/generate', async (req, res) => {
    const projectId = String(req.params.id);
    const parsed = z.object({ voice: z.string().min(1).max(40) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ code: 'BAD_REQUEST', message: parsed.error.message });

    const db = openDb(dbPath);
    const proj = db
      .prepare('SELECT lyricsJson FROM projects WHERE id=?')
      .get(projectId) as { lyricsJson: string | null } | undefined;
    if (!proj) {
      db.close();
      return res.status(404).json({ code: 'NOT_FOUND', message: 'Project not found' });
    }
    if (!proj.lyricsJson) {
      db.close();
      return res.status(400).json({ code: 'NO_LYRICS', message: 'Generate lyrics first' });
    }

    const lyrics = JSON.parse(proj.lyricsJson) as LyricsResponse;
    const text = lyrics.versions.A.sections
      .map((s) => `[${s.name}]\n${s.text}`)
      .join('\n\n')
      .slice(0, 3500);

    try {
      const { id, filePath } = await generateVoiceMp3(text, parsed.data.voice);
      const now = new Date().toISOString();
      db.prepare('INSERT INTO audio (id, projectId, voice, filePath, createdAt) VALUES (?,?,?,?,?)').run(
        id,
        projectId,
        parsed.data.voice,
        filePath,
        now,
      );
      db.close();
      res.json({ id, projectId, voice: parsed.data.voice, createdAt: now, url: `/storage/${filePath.split(/[\\/]/).pop()}` });
    } catch (e: any) {
      db.close();
      const msg = e?.message ?? 'TTS failed';
      if (msg.includes('OPENAI_API_KEY')) return res.status(500).json({ code: 'MISSING_OPENAI_KEY', message: msg });
      res.status(500).json({ code: 'TTS_FAILED', message: msg });
    }
  });

  return r;
}
