import { describe, expect, it } from 'vitest';
import { withExponentialBackoff } from './retry';

describe('withExponentialBackoff', () => {
  it('retries and succeeds', async () => {
    let n = 0;
    const r = await withExponentialBackoff(async () => {
      n++;
      if (n < 2) throw new Error('fail');
      return 42;
    });
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.value).toBe(42);
  });
});
