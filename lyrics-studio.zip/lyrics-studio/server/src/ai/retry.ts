export type RetryResult<T> = { ok: true; value: T } | { ok: false; error: Error };

export async function withExponentialBackoff<T>(fn: () => Promise<T>): Promise<RetryResult<T>> {
  const delays = [1000, 2000, 4000, 8000, 16000];
  let lastErr: Error | null = null;

  for (let attempt = 0; attempt < delays.length; attempt++) {
    try {
      const value = await fn();
      return { ok: true, value };
    } catch (e: any) {
      lastErr = e instanceof Error ? e : new Error(String(e));
      const wait = delays[attempt];
      await new Promise((r) => setTimeout(r, wait));
    }
  }

  return { ok: false, error: lastErr ?? new Error('Unknown error') };
}
