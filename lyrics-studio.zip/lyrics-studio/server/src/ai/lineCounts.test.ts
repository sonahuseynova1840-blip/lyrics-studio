import { describe, expect, it } from 'vitest';
import type { SongSettings } from '../sharedTypes';

function ensureLineCounts(settings: SongSettings, text: string, expected: number) {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length < expected) throw new Error('too short');
}

describe('section line count guard', () => {
  it('accepts enough lines', () => {
    const s: SongSettings = {
      language: 'ru',
      style: 'Rap',
      genre: 'Trap',
      mood: 'Cinematic',
      tempo: 'medium',
      density: 'high',
      rhyme: 'AABB',
      persona: 'narrator',
      theme: 'migration',
      keywords: ['night'],
      structure: { introLines: 2, verse1Lines: 4, hookLines: 2, verse2Lines: 4, bridgeLines: 2, outroLines: 2 },
    };
    expect(() => ensureLineCounts(s, 'a\n b\n', 2)).not.toThrow();
  });
});
