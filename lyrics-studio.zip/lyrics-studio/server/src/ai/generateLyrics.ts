import { z } from 'zod';
import { getOpenAI } from './openaiClient';
import { buildSystemPrompt, LyricsResponseSchema, type LyricsResponse } from './prompt';
import type { SongSettings } from '../sharedTypes';
import { withExponentialBackoff } from './retry';

function buildUserPrompt(settings: SongSettings): string {
  const s = settings.structure;
  return [
    `Theme: ${settings.theme}`,
    `Keywords: ${settings.keywords.join(', ')}`,
    `Style: ${settings.style}`,
    `Genre: ${settings.genre}`,
    `Mood: ${settings.mood}`,
    `Tempo: ${settings.tempo}`,
    `Persona: ${settings.persona}`,
    `Line counts: Intro=${s.introLines}, Verse1=${s.verse1Lines}, Hook=${s.hookLines}, Verse2=${s.verse2Lines}, Bridge=${s.bridgeLines}, Outro=${s.outroLines}`,
    '',
    'Output JSON with versions A/B/C. Each version.sections array must include exactly these names in order:',
    'Intro, Verse 1, Hook, Verse 2, Bridge, Outro.',
    'Each section.text must contain exactly the requested number of lines (split by \n).',
  ].join('\n');
}

function parseJsonStrict(text: string): unknown {
  // Remove BOM and trim
  const clean = text.replace(/^\uFEFF/, '').trim();
  return JSON.parse(clean);
}

function ensureLineCounts(settings: SongSettings, r: LyricsResponse): LyricsResponse {
  const want = {
    'Intro': settings.structure.introLines,
    'Verse 1': settings.structure.verse1Lines,
    'Hook': settings.structure.hookLines,
    'Verse 2': settings.structure.verse2Lines,
    'Bridge': settings.structure.bridgeLines,
    'Outro': settings.structure.outroLines,
  } as const;

  for (const v of ['A', 'B', 'C'] as const) {
    for (const sec of r.versions[v].sections) {
      const lines = sec.text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
      const expected = want[sec.name];
      if (lines.length < expected) {
        throw new Error(`SECTION_TOO_SHORT:${v}:${sec.name}:${lines.length}<${expected}`);
      }
    }
  }

  return r;
}

export async function generateLyrics(settings: SongSettings): Promise<LyricsResponse> {
  const openai = getOpenAI();
  const model = process.env.OPENAI_MODEL ?? 'gpt-4o-mini';

  const run = async () => {
    const resp = await openai.chat.completions.create({
      model,
      temperature: 0.9,
      messages: [
        { role: 'system', content: buildSystemPrompt(settings) },
        { role: 'user', content: buildUserPrompt(settings) },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'LyricsResponse',
          strict: true,
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              versions: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  A: { $ref: '#/$defs/version' },
                  B: { $ref: '#/$defs/version' },
                  C: { $ref: '#/$defs/version' }
                },
                required: ['A','B','C']
              },
              meta: { type: 'object' }
            },
            required: ['versions','meta'],
            $defs: {
              version: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  sections: {
                    type: 'array',
                    items: { $ref: '#/$defs/section' },
                    minItems: 6,
                    maxItems: 6
                  }
                },
                required: ['sections']
              },
              section: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  name: { type: 'string', enum: ['Intro','Verse 1','Hook','Verse 2','Bridge','Outro'] },
                  text: { type: 'string' }
                },
                required: ['name','text']
              }
            }
          }
        }
      }
    });

    const content = resp.choices[0]?.message?.content;
    if (!content) throw new Error('EMPTY_MODEL_RESPONSE');
    const json = parseJsonStrict(content);
    const parsed = LyricsResponseSchema.safeParse(json);
    if (!parsed.success) {
      throw new Error('INVALID_JSON_SCHEMA:' + parsed.error.message);
    }
    const enriched: LyricsResponse = { ...parsed.data, meta: settings } as LyricsResponse;
    return ensureLineCounts(settings, enriched);
  };

  const r1 = await withExponentialBackoff(run);
  if (!r1.ok) {
    throw r1.error;
  }

  // Quality gate (simple lexical diversity & cliché check heuristic)
  const qualityOk = checkQuality(r1.value);
  if (qualityOk) return r1.value;

  const r2 = await withExponentialBackoff(async () => {
    const extra =
      'Regenerate: increase poetic depth, imagery, internal rhymes, and avoid clichés. Keep strict language rules. Return ONLY JSON.';
    const openai2 = getOpenAI();
    const resp = await openai2.chat.completions.create({
      model,
      temperature: 0.95,
      messages: [
        { role: 'system', content: buildSystemPrompt(settings) },
        { role: 'user', content: buildUserPrompt(settings) + '\n\n' + extra },
      ],
      response_format: { type: 'json_object' },
    });
    const content = resp.choices[0]?.message?.content;
    if (!content) throw new Error('EMPTY_MODEL_RESPONSE');
    const json = parseJsonStrict(content);
    const parsed = LyricsResponseSchema.safeParse(json);
    if (!parsed.success) throw new Error('INVALID_JSON_SCHEMA:' + parsed.error.message);
    const enriched: LyricsResponse = { ...parsed.data, meta: settings } as LyricsResponse;
    return ensureLineCounts(settings, enriched);
  });

  if (!r2.ok) throw r2.error;
  if (!checkQuality(r2.value)) throw new Error('QUALITY_TOO_LOW');
  return r2.value;
}

function checkQuality(r: LyricsResponse): boolean {
  const sample = r.versions.A.sections.map((s) => s.text).join('\n');
  const words = sample
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]+/gu, ' ')
    .split(/\s+/)
    .filter(Boolean);
  const unique = new Set(words);
  const diversity = unique.size / Math.max(words.length, 1);

  const cliches = [
    'как никогда',
    'всё будет хорошо',
    'я так устал',
    'слёзы на глазах',
    'путь к мечте',
    'сердце бьётся',
    'время покажет',
  ];
  const hasCliche = cliches.some((c) => sample.toLowerCase().includes(c));

  return diversity >= 0.35 && !hasCliche;
}
