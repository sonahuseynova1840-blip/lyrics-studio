import { getOpenAI } from './openaiClient';
import type { SongSettings, LyricsResponse } from '../sharedTypes';
import { withExponentialBackoff } from './retry';
import { buildSystemPrompt } from './prompt';

export async function assistantReply(args: {
  settings: SongSettings;
  userMessage: string;
  lyrics?: LyricsResponse | null;
}): Promise<string> {
  const openai = getOpenAI();
  const model = process.env.OPENAI_MODEL ?? 'gpt-4o-mini';

  const context = args.lyrics
    ? `Current lyrics (version A):\n${args.lyrics.versions.A.sections
        .map((s) => `[${s.name}]\n${s.text}`)
        .join('\n\n')}`
    : 'No lyrics yet.';

  const run = async () => {
    const resp = await openai.chat.completions.create({
      model,
      temperature: 0.8,
      messages: [
        {
          role: 'system',
          content:
            buildSystemPrompt(args.settings) +
            '\n\nAssistant mode: give actionable suggestions, rewrites, rhyme options. Return plain text only.',
        },
        { role: 'user', content: `${context}\n\nUser request: ${args.userMessage}` },
      ],
    });
    const content = resp.choices[0]?.message?.content?.trim();
    if (!content) throw new Error('EMPTY_MODEL_RESPONSE');
    return content;
  };

  const r = await withExponentialBackoff(run);
  if (!r.ok) throw r.error;
  return r.value;
}
