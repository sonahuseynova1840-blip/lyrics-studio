import { z } from 'zod';
import type { SongSettings } from '../sharedTypes';

export function buildSystemPrompt(settings: SongSettings): string {
  const langRule =
    settings.language === 'ru'
      ? 'Output must be ONLY Russian.'
      : settings.language === 'az'
        ? 'Output must be ONLY Azerbaijani (Azərbaycan dili).'
        : settings.language === 'de'
          ? 'Output must be ONLY German.'
          : 'Output must be bilingual per line: first Russian line, then Azerbaijani equivalent line. No other languages.';

  const rhymeRule =
    settings.rhyme === 'AABB'
      ? 'Prefer AABB end-rhyme per quatrain when possible.'
      : settings.rhyme === 'ABAB'
        ? 'Prefer ABAB end-rhyme per quatrain when possible.'
        : 'Use free-rhymed but still musical rhymes (internal rhymes, assonance).';

  const densityRule =
    settings.density === 'high'
      ? 'High density: internal rhymes, multisyllabic rhymes, alliteration, assonance, tight cadence.'
      : settings.density === 'medium'
        ? 'Medium density: consistent rhymes, occasional internal rhymes, natural cadence.'
        : 'Low density: simple but still poetic rhymes, singable lines.';

  return [
    'You are a professional multilingual songwriter and rap lyricist.',
    'Write deep, poetic, professional-quality lyrics with cinematic imagery and metaphor-driven lines.',
    'Avoid clichés, generic filler, bureaucratic tone, and repetitive phrases.',
    'Ensure natural syllable flow suitable for rap/singing.',
    langRule,
    rhymeRule,
    densityRule,
    'Return ONLY valid JSON matching the required schema. No explanations, no markdown.',
    'JSON must include 3 versions: A, B, C. Each version has sections: Intro, Verse 1, Hook, Verse 2, Bridge, Outro.',
    'Each section must respect the requested line counts and include the exact header in the section name field.',
  ].join('\n');
}

export const LyricsResponseSchema = z.object({
  versions: z.object({
    A: z.object({
      sections: z.array(z.object({ name: z.enum(['Intro', 'Verse 1', 'Hook', 'Verse 2', 'Bridge', 'Outro']), text: z.string() })),
    }),
    B: z.object({
      sections: z.array(z.object({ name: z.enum(['Intro', 'Verse 1', 'Hook', 'Verse 2', 'Bridge', 'Outro']), text: z.string() })),
    }),
    C: z.object({
      sections: z.array(z.object({ name: z.enum(['Intro', 'Verse 1', 'Hook', 'Verse 2', 'Bridge', 'Outro']), text: z.string() })),
    }),
  }),
  meta: z.any(),
});

export type LyricsResponse = z.infer<typeof LyricsResponseSchema>;
