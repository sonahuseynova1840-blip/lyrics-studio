import { describe, expect, it } from 'vitest';
import { buildSystemPrompt } from './prompt';
import type { SongSettings } from '../sharedTypes';

const base: SongSettings = {
  language: 'az',
  style: 'Rap',
  genre: 'Trap',
  mood: 'Dark',
  tempo: 'medium',
  density: 'high',
  rhyme: 'AABB',
  persona: 'narrator',
  theme: 'migration',
  keywords: ['yol'],
  structure: {
    introLines: 2,
    verse1Lines: 4,
    hookLines: 2,
    verse2Lines: 4,
    bridgeLines: 2,
    outroLines: 2,
  },
};

describe('buildSystemPrompt', () => {
  it('enforces Azerbaijani', () => {
    const p = buildSystemPrompt(base);
    expect(p).toContain('ONLY Azerbaijani');
  });
});
