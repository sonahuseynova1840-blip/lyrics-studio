import fs from 'node:fs/promises';
import path from 'node:path';
import { nanoid } from 'nanoid';
import { getOpenAI } from '../ai/openaiClient';

export async function generateVoiceMp3(text: string, voice: string): Promise<{ id: string; filePath: string }> {
  const openai = getOpenAI();
  const id = nanoid();
  const storageDir = path.join(process.cwd(), 'storage');
  await fs.mkdir(storageDir, { recursive: true });
  const filePath = path.join(storageDir, `${id}.mp3`);

  const resp = await openai.audio.speech.create({
    model: process.env.OPENAI_TTS_MODEL ?? 'gpt-4o-mini-tts',
    voice: voice as any,
    format: 'mp3',
    input: text,
  });

  const buf = Buffer.from(await resp.arrayBuffer());
  await fs.writeFile(filePath, buf);
  return { id, filePath };
}
