import 'dotenv/config';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import { ensureDb } from './db/db';
import { projectsRouter } from './api/projects';

const app = express();

app.use(cors());
app.use(express.json({ limit: '2mb' }));

const dbPath = process.env.SQLITE_PATH ?? path.join(process.cwd(), 'data.sqlite');
ensureDb(dbPath);

app.use('/api', projectsRouter(dbPath));

// serve generated audio files
app.use('/storage', express.static(path.join(process.cwd(), 'storage')));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, hasOpenAIKey: Boolean(process.env.OPENAI_API_KEY) });
});

const port = Number(process.env.PORT ?? 8787);
app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`server listening on http://localhost:${port}`);
});
